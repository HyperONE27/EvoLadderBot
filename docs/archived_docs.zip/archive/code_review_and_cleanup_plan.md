# Code Review: `DataAccessService` Implementation

## 1. Overall Assessment

The migration to the `DataAccessService` is a major architectural improvement and has been largely successful. The core goal—moving "hot" table reads to an in-memory Polars DataFrame—has been achieved, and critical paths in the bot have been refactored to use this new, much faster system. The implementation correctly uses a singleton pattern, initializes data at startup, and provides an asynchronous write-back queue.

The shift to treating memory as the "source of truth" is a significant philosophical change that simplifies caching logic and improves performance. However, this shift also introduces new responsibilities, particularly around data consistency and error handling, which need to be addressed.

**Conclusion**: The implementation is **85% of the way there**. The foundation is solid, but there are critical gaps in error handling and several obsolete code artifacts that should be cleaned up to finalize the refactor.

---

## 2. Identified Faults & Risks

### 🔴 CRITICAL: Failed Database Writes Are Silently Ignored

The single most critical issue is the error handling in the `_db_writer_worker`.

**Code:** (`src/backend/services/data_access_service.py:410-411`)
```python
        except Exception as e:
            print(f"[DataAccessService] ERROR: Failed to process write job {job.job_type}: {e}")
```

**Problem**: If an asynchronous write to Supabase fails (e.g., due to a network issue, constraint violation, or API outage), the error is simply printed to the console, and the `WriteJob` is discarded. This leads to a dangerous state where the **in-memory data and the persistent database are now permanently out of sync.** The bot will continue operating with the correct in-memory data, but this change is lost forever from the true source of record.

**Recommendation**: This must be fixed. A robust system should be implemented, such as:
1.  **Retry Mechanism**: Implement a retry policy (e.g., exponential backoff) for transient errors.
2.  **Dead-Letter Queue**: If a write fails after several retries, move it to a "dead-letter" queue or log it to a file for manual review by an administrator. The system must not simply drop the data.

### 🟡 MAJOR: Lingering Fallback Logic

The "fail loud" philosophy was implemented, but some fallback logic remains, which contradicts the new architecture.

**Code:** (`src/backend/services/data_access_service.py:1287-1299`)
In the `abort_match` method, there is still a fallback to reading from the database if the match isn't found in memory.
```python
            # Get match data from memory first
            match = self.get_match(match_id)
            if not match:
                # Fall back to DB if not in memory
                from src.backend.db.db_reader_writer import DatabaseReader
                db_reader = DatabaseReader()
                match_data = db_reader.get_match_1v1(match_id)
```
**Problem**: This violates the principle that `DataAccessService` is the source of truth. If a match isn't in memory, it should be treated as an error, consistent with the `get_match_mmrs` implementation.

---

## 3. Obsolete Code & Cleanup Plan

The recent refactoring has made a significant amount of the old caching and data access logic obsolete. This dead code should be removed to improve clarity and maintainability.

### Obsolete Components:

1.  **Leaderboard Service Caching (`src/backend/services/leaderboard_service.py`)**:
    *   `_leaderboard_cache` global variable.
    *   `invalidate_leaderboard_cache()` function (already marked as deprecated).
    *   `_refresh_leaderboard_worker()` function (already marked as deprecated).
    *   `_get_cached_leaderboard_dataframe_async()` method is now overly complex and relies on the dead worker logic.
    *   `get_player_mmr_from_cache()`, `get_player_info_from_cache()`, and `get_player_all_mmrs_from_cache()` are now redundant. Other services should call `DataAccessService` directly.
    *   The static `invalidate_cache()` method is also obsolete.

2.  **Ranking Service Background Refresh (`src/backend/services/ranking_service.py`)**:
    *   The `start_background_refresh()` and `stop_background_refresh()` methods are now dead code since they are no longer called from `bot_setup.py`.
    *   The `_background_task` instance variable is unused.

3.  **Bot Setup (`src/bot/bot_setup.py`)**:
    *   The commented-out code for starting/stopping the ranking service refresh can be completely removed.

### Scan for Remaining Direct DB Calls:

A `grep` for `db_reader` and `db_writer` reveals numerous instances. Many are in documentation and test files, but some application logic needs review:
*   **`src/backend/services/app_context.py`**: Still creates global instances of `db_reader` and `db_writer`. While `DataAccessService` is the intended path, these global instances still allow other services to bypass it.
*   **`src/backend/services/matchmaking_service.py`**: The `add_player` method still contains a fallback to `self.db_reader` and `self.db_writer` if a player's MMR is not found in the `leaderboard_service` cache (which is now just `DataAccessService`). This logic needs to be updated to use `DataAccessService` directly for both reads and writes.
*   **`src/bot/bot_setup.py`**: The `_log_command_async` method still uses `db_writer` directly. This should be migrated to `DataAccessService.insert_command_call`.

---

## 4. Recommended Next Steps

Here is a concrete plan to finalize the refactoring:

1.  **[CRITICAL] Implement Write Job Error Handling**:
    *   Modify `_process_write_job` in `DataAccessService` to catch exceptions.
    *   Implement a simple retry mechanism for failed writes.
    *   If retries fail, serialize the failed `WriteJob` to a log file (`failed_writes.log`) for manual inspection.

2.  **Remove Fallback in `abort_match`**:
    *   Update `data_access_service.abort_match` to remove the database fallback and raise a `ValueError` if the match is not in memory.

3.  **Full Obsolete Code Removal**:
    *   **Task 1**: Completely remove the deprecated functions, methods, and variables from `leaderboard_service.py` identified in section 3. Simplify `_get_cached_leaderboard_dataframe_async` to be a simple async wrapper around the synchronous `get_leaderboard_dataframe` or remove it if unused.
    *   **Task 2**: Remove the `start_background_refresh` and `stop_background_refresh` methods from `ranking_service.py`.
    *   **Task 3**: Delete the commented-out code from `bot_setup.py`.

4.  **Final Migration of DB Calls**:
    *   **Task 4**: Refactor `matchmaking_service.add_player` to use `DataAccessService` for getting and creating player MMRs, removing the direct `db_reader` and `db_writer` calls.
    *   **Task 5**: Refactor `bot_setup.py`'s `_log_command_async` to use `DataAccessService.insert_command_call`.
    *   **Task 6**: Review `app_context.py`. While removing the global `db_reader` and `db_writer` might be too disruptive, add a prominent comment indicating they are for **legacy use only** and that `DataAccessService` is the preferred entry point.

5.  **Enhance Test Coverage**:
    *   **Task 7**: Write a new test specifically to simulate a failed database write and assert that the `DataAccessService` correctly handles the error (e.g., retries and/or logs to a dead-letter file). This will validate the fix from step 1.
