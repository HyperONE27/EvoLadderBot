# Phase 5: Optimize Abort, Replay, and Result Flows

## Performance Analysis from Logs

### Current Bottlenecks:
1. **Match Abort: 3330ms** (`execute_abort_complete`)
2. **Match Data Lookup: 250-630ms** (not using DataAccessService)
3. **Match Embed Generation: 250-630ms total**
4. **Replay Upload: Synchronous** (blocking user experience)

### Target Performance:
- Match abort: <100ms
- Match data lookup: <1ms
- Match embed: <50ms
- Replay upload acknowledgment: Instant (<10ms)

---

## Implementation Plan

### 1. Add Match Data Methods to DataAccessService
**Impact:** 250-630ms → <1ms

```python
# Add to DataAccessService:
def get_match(match_id: int) -> Optional[Dict]
def get_match_for_player(discord_uid: int) -> Optional[Dict]
```

### 2. Refactor Replay Upload Flow
**Impact:** Instant UI feedback, async processing

**Current Flow (Blocking):**
1. Download replay file
2. Parse replay (CPU intensive)
3. Upload to storage
4. Write to database (BLOCKING)
5. Update match view
6. Send replay embed

**New Flow (Non-Blocking):**
1. Download replay file
2. **INSTANT:** Update match view "Replay Uploaded ✓"
3. **INSTANT:** Unlock result reporting dropdowns
4. **ASYNC:** Parse replay in background
5. **ASYNC:** Upload to storage
6. **ASYNC:** Write to database (with `uploaded_at`)
7. **ASYNC:** Send replay details embed (a few seconds later)

### 3. Optimize Match Abort Flow
**Impact:** 3330ms → <100ms

- Make abort DB write async via DataAccessService
- Update remaining aborts instantly in memory
- Update UI immediately
- Process completion check in background

### 4. Add `uploaded_at` Column Support
- Update replay insert to include `uploaded_at` timestamp
- Use `get_timestamp()` for consistency

---

## Implementation Tasks

### Task 1: Add Match Lookup to DataAccessService
- [ ] Implement `get_match(match_id)` 
- [ ] Test match lookup performance

### Task 2: Refactor Replay Upload
- [ ] Split into instant acknowledgment + async processing
- [ ] Update `store_upload_from_parsed_dict_async` to include `uploaded_at`
- [ ] Update match view immediately on upload
- [ ] Send replay embed after processing completes
- [ ] Test replay upload flow

### Task 3: Optimize Abort Flow
- [ ] Add async abort method to DataAccessService
- [ ] Refactor abort button to use async writes
- [ ] Test abort performance

### Task 4: Comprehensive Testing
- [ ] Test all flows end-to-end
- [ ] Validate performance improvements
- [ ] Check for race conditions

---

## Expected Results

### Before:
- Match data lookup: 250-630ms
- Abort: 3330ms
- Replay upload: Blocking (1-2 seconds)

### After:
- Match data lookup: <1ms (99.8% faster)
- Abort: <100ms (97% faster)
- Replay upload UI: Instant
- Replay processing: Background (non-blocking)

**Total Savings:** ~4-5 seconds per match interaction

