# DataAccessService Deployment Checklist

## Pre-Deployment (Complete ✅)

- [x] All code implemented and tested
- [x] Performance benchmarks validated
- [x] Test suite passing (100%)
- [x] Documentation complete
- [x] Error handling verified
- [x] Memory usage acceptable

---

## Database Migration (Required)

### Step 1: Add `uploaded_at` Column to Replays Table

**SQL Command:**
```sql
ALTER TABLE replays ADD COLUMN uploaded_at TIMESTAMP DEFAULT NOW();
```

**Validation:**
```sql
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'replays' AND column_name = 'uploaded_at';
```

**Expected Result:**
```
column_name  | data_type                   | is_nullable | column_default
uploaded_at  | timestamp without time zone | YES         | now()
```

---

## Deployment Steps

### Step 1: Stop Bot
```bash
# Stop the running bot process
ps aux | grep "python.*main.py"
kill <PID>
```

### Step 2: Backup Current State (Optional)
```bash
# Create a backup of current bot state
cd ~/EvoLadderBot
git stash
git branch backup-pre-dataaccessservice
```

### Step 3: Pull Latest Code
```bash
git pull origin main
# OR if working from a branch:
git checkout feature/data-access-service
git pull origin feature/data-access-service
```

### Step 4: Verify Dependencies
```bash
pip install -r requirements.txt --upgrade
# Ensure polars is installed
pip show polars
```

### Step 5: Run Migration SQL
```bash
# Connect to Supabase and run the ALTER TABLE command
# (Use Supabase dashboard SQL editor or psql)
```

### Step 6: Start Bot
```bash
python src/bot/main.py
```

### Step 7: Monitor Startup Logs

**Expected Output:**
```
[Startup] Initializing DataAccessService...
[DataAccessService] Starting async initialization...
[DataAccessService] Loading all tables from database...
[DataAccessService]   Loading players...
[DataAccessService]   Players loaded: 259 rows
[DataAccessService]   Loading mmrs_1v1...
[DataAccessService]   MMRs loaded: 1081 rows
[DataAccessService]   Loading preferences_1v1...
[DataAccessService]   Preferences loaded: 255 rows
[DataAccessService]   Loading matches_1v1...
[DataAccessService]   Matches loaded: 32 rows
[DataAccessService]   Loading replays...
[DataAccessService]   Replays loaded: 27 rows
[DataAccessService] Async initialization complete in 1399.58ms
[INFO] DataAccessService initialized successfully
```

**Watch For:**
- ❌ `[FATAL] Failed to initialize DataAccessService` - Bot will exit, check DB connection
- ❌ `WARNING: DataFrames not initialized` - Initialization failed, check logs
- ✅ `DataAccessService initialized successfully` - Good to go!

---

## Post-Deployment Validation

### Step 1: Basic Smoke Test (5 minutes)

1. **Join Queue:**
   - Use `/queue` command
   - Verify no errors in logs

2. **Match Found:**
   - Wait for or trigger a match
   - Check logs for: `⏱️ [MatchEmbed PERF] TOTAL get_embed() took X.XXms`
   - **Target:** <5ms (was 600-800ms)

3. **Abort Match:**
   - Click abort button
   - Check logs for abort execution time
   - **Target:** <100ms (was 3330ms)

4. **Replay Upload:**
   - Upload a replay file
   - Verify dropdowns unlock immediately
   - Check logs for async write queue activity
   - **Target:** Non-blocking, instant UI update

### Step 2: Performance Verification (10 minutes)

Monitor logs for performance metrics:

```
# Good Performance Indicators:
⏱️ [MatchEmbed PERF] Player info lookup: 0.76ms ✅
  [MatchEmbed PERF] Rank lookup: 0.01ms ✅
  [MatchEmbed PERF] Match data lookup: 0.19ms ✅
  [MatchEmbed PERF] Abort count lookup: 0.87ms ✅
⚠️ [MatchEmbed PERF] TOTAL get_embed() took 2.31ms ✅

# Bad Performance Indicators (rollback if seen):
⏱️ [MatchEmbed PERF] TOTAL get_embed() took 600ms ❌
⏱️ [Abort PERF] execute_abort took 3000ms ❌
```

### Step 3: Data Consistency Check (5 minutes)

1. **Create a new player:**
   - Use `/setup` command
   - Verify player appears in database

2. **Update player info:**
   - Change country, name, etc.
   - Check database to confirm changes persisted

3. **Play a match:**
   - Complete a full match flow
   - Verify MMR updates in database

4. **Check write queue stats on next bot restart:**
   ```
   [DataAccessService]   Total writes queued: 150
   [DataAccessService]   Total writes completed: 150
   [DataAccessService]   Peak queue size: 5
   ```
   - Writes queued should equal writes completed ✅
   - Peak queue size should be low (<20) ✅

### Step 4: Memory Monitoring (24 hours)

Monitor memory usage over time:

```bash
# On Linux/Mac:
ps aux | grep "python.*main.py" | awk '{print $6/1024 " MB"}'

# Expected: 130-150 MB (stable over time)
```

**Watch For:**
- ⚠️ Memory increasing continuously (memory leak)
- ⚠️ Memory >500 MB (too much data in memory)

---

## Rollback Plan (If Needed)

### If Bot Fails to Start:

1. **Check DataAccessService initialization error:**
   ```
   [FATAL] Failed to initialize DataAccessService: <error>
   ```

2. **Rollback to previous version:**
   ```bash
   git checkout backup-pre-dataaccessservice
   python src/bot/main.py
   ```

3. **Debug offline:**
   - Run tests: `python tests/test_quick_phase5.py`
   - Check DB connection
   - Verify schema changes applied correctly

### If Performance is Worse:

1. **Check for "DataFrame not initialized" warnings:**
   - Indicates async initialization failed
   - Check bot startup logs

2. **Verify singleton pattern working:**
   - Only one DataAccessService instance should exist
   - Check for multiple initialization messages

3. **If all else fails, rollback:**
   ```bash
   git checkout backup-pre-dataaccessservice
   python src/bot/main.py
   ```

---

## Success Criteria

### Must Have (Critical) ✅
- [x] Bot starts successfully
- [x] DataAccessService initializes without errors
- [x] Match embed generation <50ms (target: <5ms)
- [x] Abort execution <100ms (target: <1ms)
- [x] No Discord interaction timeouts
- [x] Data persists to database

### Should Have (Important)
- [ ] Player info lookup <1ms
- [ ] Match data lookup <1ms
- [ ] Abort count lookup <1ms
- [ ] Replay uploads non-blocking
- [ ] Memory usage <200 MB

### Nice to Have (Optional)
- [ ] Zero warnings in logs
- [ ] Write queue always <10 items
- [ ] All operations <5ms

---

## Monitoring Dashboard (Post-Deployment)

### Key Metrics to Track

1. **Performance:**
   - Match embed generation time (target: <5ms)
   - Abort execution time (target: <1ms)
   - Player lookup time (target: <1ms)

2. **Reliability:**
   - Discord interaction timeout rate (target: 0%)
   - DataAccessService initialization success rate (target: 100%)
   - Write queue processing success rate (target: 100%)

3. **Resource Usage:**
   - Memory usage (target: 130-150 MB)
   - Write queue peak size (target: <20)
   - Database connection pool utilization

### Alert Thresholds

- 🚨 **Critical:** Match embed >100ms
- 🚨 **Critical:** Bot fails to start
- ⚠️ **Warning:** Memory >300 MB
- ⚠️ **Warning:** Write queue >50 items
- ℹ️ **Info:** Any operation >10ms

---

## Support & Troubleshooting

### Common Issues

**Issue 1: "DataFrame not initialized" warnings**
- **Cause:** DataAccessService.initialize_async() not called
- **Fix:** Check bot_setup.py initialization sequence

**Issue 2: Slow performance (still seeing 500ms+ queries)**
- **Cause:** Code still using old db_reader directly
- **Fix:** Verify all services migrated to DataAccessService

**Issue 3: Data not persisting to database**
- **Cause:** Write queue not processing or bot shutdown before flush
- **Fix:** Check shutdown logs for write counts, ensure graceful shutdown

**Issue 4: Memory usage very high (>500 MB)**
- **Cause:** Too many rows in hot tables
- **Fix:** Implement row limits for matches/replays tables

### Debug Commands

```bash
# Check if bot is running
ps aux | grep "python.*main.py"

# Monitor bot logs in real-time
tail -f bot.log

# Check memory usage
ps -p <PID> -o %mem,rss,vsz

# Verify database schema
psql <connection_string> -c "\d replays"
```

---

## Final Sign-Off

- [ ] Database migration successful
- [ ] Bot deployed and running
- [ ] All smoke tests passed
- [ ] Performance metrics validated
- [ ] Monitoring in place
- [ ] Team notified

**Deployed by:** _____________  
**Date:** _____________  
**Sign-off:** _____________

---

*Checklist Version: 1.0*
*Last Updated: October 22, 2025*


