import asyncio
import json
import logging
from functools import partial
from typing import Callable, Dict, Optional

import discord
from discord import app_commands

from src.backend.db.db_reader_writer import get_timestamp
from src.bot.config import QUEUE_SEARCHING_HEARTBEAT_SECONDS
from src.backend.services.app_context import (
    command_guard_service as guard_service,
    maps_service,
    mmr_service,
    notification_service,
    queue_service,
    races_service as race_service,
    regions_service,
    replay_service,
    user_info_service,
)
from src.backend.services.command_guard_service import CommandGuardError
from src.backend.services.match_completion_service import match_completion_service
from src.backend.services.matchmaking_service import MatchResult, Player, QueuePreferences, matchmaker
from src.backend.services.replay_service import ReplayRaw, parse_replay_data_blocking
from src.backend.services.user_info_service import get_user_info
from src.bot.components.cancel_embed import create_cancel_embed
from src.bot.components.command_guard_embeds import create_command_guard_error_embed
from src.bot.components.confirm_restart_cancel_buttons import ConfirmRestartCancelButtons
from src.bot.components.error_embed import ErrorEmbedException, create_error_view_from_exception
from src.bot.utils.command_decorators import dm_only
from src.bot.utils.discord_utils import (
    format_discord_timestamp,
    get_current_unix_timestamp,
    get_flag_emote,
    get_race_emote,
    send_ephemeral_response,
    get_rank_emote,
)
import time
from contextlib import suppress

from src.backend.services.performance_service import FlowTracker
from src.bot.components.replay_details_embed import ReplayDetailsEmbed
from src.bot.config import GLOBAL_TIMEOUT


class QueueSearchingViewManager:
    """Manage active queue searching views safely across async tasks."""

    def __init__(self) -> None:
        self._views: Dict[int, "QueueSearchingView"] = {}
        self._lock = asyncio.Lock()

    async def has_view(self, user_id: int) -> bool:
        async with self._lock:
            return user_id in self._views

    async def get_view(self, user_id: int) -> Optional["QueueSearchingView"]:
        async with self._lock:
            return self._views.get(user_id)

    async def register(self, user_id: int, view: "QueueSearchingView") -> None:
        previous: Optional["QueueSearchingView"] = None
        async with self._lock:
            previous = self._views.get(user_id)
            self._views[user_id] = view
        if previous and previous is not view:
            previous.deactivate()

    async def unregister(
        self,
        user_id: int,
        *,
        deactivate: bool = True,
        view: Optional["QueueSearchingView"] = None,
    ) -> Optional["QueueSearchingView"]:
        async with self._lock:
            current = self._views.get(user_id)
            if current is None or (view is not None and current is not view):
                return None
            self._views.pop(user_id, None)
        if deactivate and current:
            current.deactivate()
        return current


class MatchFoundViewManager:
    """Manage active match found views safely across async tasks."""

    def __init__(self) -> None:
        # {match_id: [(channel_id, view)]}
        self._views: Dict[int, list[tuple[int, "MatchFoundView"]]] = {}
        self._lock = asyncio.Lock()

    async def register(self, match_id: int, channel_id: int, view: "MatchFoundView") -> None:
        async with self._lock:
            if match_id not in self._views:
                self._views[match_id] = []
            
            # Remove any stale view for the same channel
            self._views[match_id] = [
                (cid, v) for cid, v in self._views[match_id] if cid != channel_id
            ]
            self._views[match_id].append((channel_id, view))
            channel_to_match_view_map[channel_id] = view

    async def unregister(self, match_id: int, channel_id: int) -> None:
        async with self._lock:
            if match_id in self._views:
                self._views[match_id] = [
                    (cid, v) for cid, v in self._views[match_id] if cid != channel_id
                ]
                if not self._views[match_id]:
                    del self._views[match_id]
            channel_to_match_view_map.pop(channel_id, None)

    async def get_views_by_match_id(self, match_id: int) -> list[tuple[int, "MatchFoundView"]]:
        async with self._lock:
            return self._views.get(match_id, [])


queue_searching_view_manager = QueueSearchingViewManager()
match_found_view_manager = MatchFoundViewManager()
channel_to_match_view_map: Dict[int, "MatchFoundView"] = {}

logger = logging.getLogger(__name__)


# Register Command
def register_queue_command(tree: app_commands.CommandTree):
    """Register the queue command"""
    @tree.command(
        name="queue",
        description="Join the matchmaking queue"
    )
    async def queue(interaction: discord.Interaction):
        await queue_command(interaction)
    
    return queue


# UI Elements
@dm_only
async def queue_command(interaction: discord.Interaction):
    """Handle the /queue slash command"""
    flow = FlowTracker("queue_command", user_id=interaction.user.id)
    
    try:
        # Guard checks
        flow.checkpoint("guard_checks_start")
        player = guard_service.ensure_player_record(interaction.user.id, interaction.user.name)
        guard_service.require_queue_access(player)
        flow.checkpoint("guard_checks_complete")
    except CommandGuardError as exc:
        flow.complete("guard_check_failed")
        error_embed = create_command_guard_error_embed(exc)
        await send_ephemeral_response(interaction, embed=error_embed)
        return

    # Check for existing queue/match
    flow.checkpoint("check_existing_queue_start")
    is_in_match_view = any(
        v.match_result.player_1_discord_id == interaction.user.id or v.match_result.player_2_discord_id == interaction.user.id
        for v in channel_to_match_view_map.values()
    )

    # Prevent multiple queue attempts or queuing while a match is active
    if await queue_searching_view_manager.has_view(interaction.user.id) or is_in_match_view:
        flow.complete("already_queued")
        error = ErrorEmbedException(
            title="Queueing Not Allowed",
            description="You are already in a queue or an active match."
        )
        error_view = create_error_view_from_exception(error)
        await send_ephemeral_response(interaction, embed=error_view.embed, view=error_view)
        return
    
    flow.checkpoint("check_existing_queue_complete")
    
    # Get user's saved preferences from DataAccessService (in-memory, instant)
    flow.checkpoint("load_preferences_start")
    from src.backend.services.data_access_service import DataAccessService
    data_service = DataAccessService()
    user_preferences = data_service.get_player_preferences(interaction.user.id)
    
    if user_preferences:
        # Parse saved preferences from database
        try:
            default_races = json.loads(user_preferences['last_chosen_races'])
            default_maps = json.loads(user_preferences['last_chosen_vetoes'])
        except (json.JSONDecodeError, TypeError, KeyError):
            # If parsing fails or keys don't exist, use empty defaults
            default_races = []
            default_maps = []
    else:
        # No saved preferences, use empty defaults
        default_races = []
        default_maps = []
    
    flow.checkpoint("load_preferences_complete")
    
    # Create view
    flow.checkpoint("create_view_start")
    view = await QueueView.create(
        discord_user_id=interaction.user.id,
        default_races=default_races,
        default_maps=default_maps,
    )
    flow.checkpoint("create_view_complete")
    
    # Build embed
    flow.checkpoint("build_embed_start")
    embed = view.get_embed()
    flow.checkpoint("build_embed_complete")
    
    # Send response
    flow.checkpoint("send_response_start")
    await send_ephemeral_response(interaction, embed=embed, view=view)
    flow.checkpoint("send_response_complete")
    
    flow.complete("success")


class MapVetoSelect(discord.ui.Select):
    """Multiselect dropdown for map vetoes"""
    
    def __init__(self, default_values=None):
        # Get map options from ladder service
        maps = maps_service.get_maps()
        
        options = []
        for map_data in maps:
            options.append(
                discord.SelectOption(
                    label=map_data["short_name"],
                    value=map_data["short_name"],
                    default=map_data["short_name"] in (default_values or [])
                )
            )
        
        super().__init__(
            placeholder="Select maps to veto (max 4)...",
            min_values=0,
            max_values=4,
            options=options,
            row=3
        )
    
    async def callback(self, interaction: discord.Interaction):
        self.view.vetoed_maps = self.values
        await self.view.persist_preferences()
        await self.view.update_embed(interaction)


class JoinQueueButton(discord.ui.Button):
    """Join queue button"""
    
    def __init__(self):
        super().__init__(
            label="Join Queue",
            emoji="🚀",
            style=discord.ButtonStyle.secondary,
            row=0
        )
    
    async def callback(self, interaction: discord.Interaction):
        flow = FlowTracker("join_queue_button", user_id=interaction.user.id)
        
        flow.checkpoint("defer_interaction_start")
        # Defer the interaction immediately to prevent timeouts
        await interaction.response.defer()
        flow.checkpoint("defer_interaction_complete")

        flow.checkpoint("validate_race_selection")
        # Validate that at least one race is selected
        if not self.view.get_selected_race_codes():
            # Create error exception with restart button only
            error = ErrorEmbedException(
                title="No Race Selected",
                description="You must select at least one race before joining the queue.",
                reset_target=self.view  # Reset to the same queue view
            )
            
            # Create error view with only restart button enabled
            error_view = create_error_view_from_exception(error)
            # Override the error view to only include restart button
            error_view.clear_items()
            restart_buttons = ConfirmRestartCancelButtons.create_buttons(
                reset_target=self.view,
                include_confirm=False,
                include_restart=True,
                include_cancel=False
            )
            for button in restart_buttons:
                error_view.add_item(button)
            
            flow.complete("validation_failed_no_race")
            await interaction.followup.send(
                embed=error_view.embed,
                view=error_view,
                ephemeral=True
            )
            return
        
        flow.checkpoint("get_user_info")
        # Get user info
        user_info = get_user_info(interaction)
        user_id = user_info["id"]

        flow.checkpoint("check_duplicate_queue")
        # Prevent multiple queue attempts or queuing while a match is active
        if await queue_searching_view_manager.has_view(user_id) or interaction.user.id in match_results:
            flow.complete("already_queued")
            error = ErrorEmbedException(
                title="Queueing Not Allowed",
                description="You cannot queue more than once, or while a match is active."
            )
            error_view = create_error_view_from_exception(error)
            await interaction.followup.send(embed=error_view.embed, view=error_view, ephemeral=True)
            return
        
        flow.checkpoint("persist_preferences")
        # Persist current preferences before joining queue
        await self.view.persist_preferences()
        
        flow.checkpoint("create_queue_preferences")
        # Create queue preferences
        preferences = QueuePreferences(
            selected_races=self.view.get_selected_race_codes(),
            vetoed_maps=self.view.vetoed_maps,
            discord_user_id=user_id,
            user_id="Player" + str(user_id)  # TODO: Get actual user ID from database
        )
        
        flow.checkpoint("create_player_object")
        # Create player and add to matchmaking queue
        player = Player(
            discord_user_id=user_id,
            user_id=preferences.user_id,
            preferences=preferences
        )
        
        flow.checkpoint("add_player_to_matchmaker_start")
        # Add player to matchmaker
        print(f"🎮 Adding player to matchmaker: {player.user_id}")
        await matchmaker.add_player(player)
        flow.checkpoint("add_player_to_matchmaker_complete")
        
        flow.checkpoint("create_searching_view")
        # Show searching state
        searching_view = QueueSearchingView(
            original_view=self.view,
            selected_races=self.view.get_selected_race_codes(),
            vetoed_maps=self.view.vetoed_maps,
            player=player
        )
        
        flow.checkpoint("register_view_manager")
        await queue_searching_view_manager.register(user_id, searching_view)
        
        flow.checkpoint("start_status_updates")
        searching_view.start_status_updates()
        
        flow.checkpoint("build_and_send_embed_start")
        await interaction.edit_original_response(
            embed=searching_view.build_searching_embed(),
            view=searching_view
        )
        flow.checkpoint("build_and_send_embed_complete")
        
        # Store the interaction so we can update the message when match is found
        searching_view.set_interaction(interaction)
        
        flow.complete("success")


class ClearSelectionsButton(discord.ui.Button):
    """Clear all selections button"""
    
    def __init__(self):
        super().__init__(
            label="Clear All Selections",
            emoji="🗑️",
            style=discord.ButtonStyle.danger,  # Red
            row=0
        )
    
    async def callback(self, interaction: discord.Interaction):
        # Clear all selections
        self.view.selected_bw_race = None
        self.view.selected_sc2_race = None
        self.view.vetoed_maps = []
        
        # Update the view with cleared selections
        await self.view.persist_preferences()
        await self.view.update_embed(interaction)


class CancelQueueSetupButton(discord.ui.Button):
    """Cancel button that shows cancel embed"""
    
    def __init__(self):
        super().__init__(
            label="Cancel",
            emoji="✖️",
            style=discord.ButtonStyle.danger,
            row=0
        )
    
    async def callback(self, interaction: discord.Interaction):
        # Create and show the cancel embed
        cancel_view = create_cancel_embed()
        await interaction.response.edit_message(
            content="",
            embed=cancel_view.embed,
            view=cancel_view
        )


class QueueView(discord.ui.View):
    """Main queue view with race and map veto selections"""
    
    def __init__(self, discord_user_id: int, default_races=None, default_maps=None):
        super().__init__(timeout=GLOBAL_TIMEOUT)
        self.discord_user_id = discord_user_id
        default_races = default_races or []
        self.selected_bw_race = next((race for race in default_races if race.startswith("bw_")), None)
        self.selected_sc2_race = next((race for race in default_races if race.startswith("sc2_")), None)
        self.vetoed_maps = default_maps or []
        self.add_item(JoinQueueButton())
        self.add_item(ClearSelectionsButton())
        self.add_item(CancelQueueSetupButton())
        self.add_item(BroodWarRaceSelect(default_value=self.selected_bw_race))
        self.add_item(StarCraftRaceSelect(default_value=self.selected_sc2_race))
        self.add_item(MapVetoSelect(default_values=default_maps))


    @classmethod
    async def create(cls, discord_user_id: int, default_races=None, default_maps=None) -> "QueueView":
        view = cls(discord_user_id, default_races=default_races, default_maps=default_maps)
        # Don't persist preferences immediately - only when user makes changes
        return view

    def get_selected_race_codes(self) -> list[str]:
        races: list[str] = []
        if self.selected_bw_race:
            races.append(self.selected_bw_race)
        if self.selected_sc2_race:
            races.append(self.selected_sc2_race)
        return races

    async def persist_preferences(self) -> None:
        races_payload = json.dumps(self.get_selected_race_codes())
        # Sort vetoed maps alphabetically before saving to DB
        sorted_vetoes = sorted(self.vetoed_maps)
        vetoes_payload = json.dumps(sorted_vetoes)

        try:
            # Use DataAccessService for async write
            from src.backend.services.data_access_service import DataAccessService
            data_service = DataAccessService()
            
            # Call async method directly
            await data_service.update_player_preferences(
                discord_uid=self.discord_user_id,
                last_chosen_races=races_payload,
                last_chosen_vetoes=vetoes_payload
            )
        except Exception as exc:  # pragma: no cover — log and continue
            logger.error("Failed to update 1v1 preferences for user %s: %s", self.discord_user_id, exc)
    
    def get_embed(self):
        """Get the embed for this view without requiring an interaction"""
        embed = discord.Embed(
            title="🎮 Matchmaking Queue",
            description="Configure your queue preferences",
            color=discord.Color.blue()
        )
        
        # Add race selection info
        selected_codes = self.get_selected_race_codes()
        if selected_codes:
            details = []
            for code in selected_codes:
                label = race_service.get_race_group_label(code)
                name = race_service.get_race_name(code)
                # Get race emote for display
                race_emote = get_race_emote(code)
                # Simplify the label (remove BW/SC2 suffix)
                if label == "Brood War":
                    simplified_label = "Brood War"
                elif label == "StarCraft II":
                    simplified_label = "StarCraft II"
                else:
                    simplified_label = label
                details.append(f"- {simplified_label}: {race_emote} {name}")
            race_list = "\n".join(details)
            embed.add_field(
                name="Selected Races",
                value=race_list,
                inline=False
            )
        else:
            embed.add_field(
                name="Selected Races",
                value="None selected",
                inline=False
            )
        
        # Add map veto info
        veto_count = len(self.vetoed_maps)
        if self.vetoed_maps:
            # Sort maps according to the service's defined order
            map_order = maps_service.get_map_short_names()
            sorted_maps = [map_name for map_name in map_order if map_name in self.vetoed_maps]
            # Add Discord number emotes
            number_emotes = [":one:", ":two:", ":three:", ":four:"]
            map_list = "\n".join([f"{number_emotes[i]} {map_name}" for i, map_name in enumerate(sorted_maps)])
            embed.add_field(
                name=f"Vetoed Maps ({veto_count}/4)",
                value=map_list,
                inline=False
            )
        else:
            embed.add_field(
                name="Vetoed Maps (0/4)",
                value="No vetoes",
                inline=False
            )
        
        return embed
    
    async def update_embed(self, interaction: discord.Interaction):
        """Update the embed with current selections"""
        embed = self.get_embed()
        new_view = await QueueView.create(
            discord_user_id=self.discord_user_id,
            default_races=self.get_selected_race_codes(),
            default_maps=self.vetoed_maps,
        )
        await interaction.response.edit_message(embed=embed, view=new_view)


class QueueSearchingView(discord.ui.View):
    """View shown while searching for a match"""
    
    def __init__(self, original_view, selected_races, vetoed_maps, player):
        super().__init__(timeout=GLOBAL_TIMEOUT)
        self.original_view = original_view
        self.selected_bw_race = next((code for code in selected_races if code.startswith("bw_")), None)
        self.selected_sc2_race = next((code for code in selected_races if code.startswith("sc2_")), None)
        self.vetoed_maps = vetoed_maps
        self.player = player
        self.last_interaction = None
        self.is_active = True
        self.status_task: Optional[asyncio.Task] = None
        self.match_task: Optional[asyncio.Task] = None
        self.status_lock = asyncio.Lock()
        self.last_interaction = None
        
        # Add cancel button
        self.add_item(CancelQueueButton(original_view, player))
        
        # Start async match listener (push-based notifications)
        self.match_task = asyncio.create_task(self._listen_for_match())
    
    def start_status_updates(self) -> None:
        if self.status_task is None:
            self.status_task = asyncio.create_task(self.periodic_status_update())

    async def periodic_status_update(self):
        while self.is_active:
            if not await queue_searching_view_manager.has_view(self.player.discord_user_id):
                break
            await asyncio.sleep(QUEUE_SEARCHING_HEARTBEAT_SECONDS)
            if not self.is_active or self.last_interaction is None:
                continue
            async with self.status_lock:
                if not self.is_active:
                    continue
                try:
                    await self.last_interaction.edit_original_response(
                        embed=self.build_searching_embed(),
                        view=self
                    )
                except Exception:
                    pass

    def build_searching_embed(self) -> discord.Embed:
        stats = matchmaker.get_queue_snapshot()
        next_wave_epoch = matchmaker.get_next_matchmaking_time()
        embed = discord.Embed(
            title="🔍 Searching...",
            description=(
                "The queue is searching for a game.\n\n"
                f"- Search interval: {matchmaker.MATCH_INTERVAL_SECONDS} seconds\n"
                f"- Next match wave: <t:{next_wave_epoch}:R>\n"
                f"- Unique players seen in the last 15 minutes: {stats['active_population']}\n"
                "- Current players queueing:\n"
                f"  - Brood War: {stats['bw_only']}\n"
                f"  - StarCraft II: {stats['sc2_only']}\n"
                f"  - Both: {stats['both_races']}"
            ),
            color=discord.Color.blue()
        )
        return embed
    
    async def _listen_for_match(self):
        """
        Listen for match notifications (push-based, not polling).
        
        This method blocks until a match is found and published by the notification service.
        It provides instant notification without the overhead and delay of polling.
        """
        flow = FlowTracker(f"listen_for_match", user_id=self.player.discord_user_id)
        
        flow.checkpoint("subscribe_to_notifications")
        # Subscribe to notifications and get our personal queue
        notification_queue = await notification_service.subscribe(self.player.discord_user_id)
        
        try:
            flow.checkpoint("waiting_for_match")
            # Block here until a match is published (instant notification!)
            match_result = await notification_queue.get()
            flow.checkpoint("match_notification_received")
            
            flow.checkpoint("process_match_result_start")
            # Match found! Update the view immediately
            is_player1 = match_result.player_1_discord_id == self.player.discord_user_id
            
            flow.checkpoint("create_match_found_view")
            # Create match found view
            match_view = MatchFoundView(match_result, is_player1)
            
            flow.checkpoint("update_match_view_start")
            # Edit the searching message in DMs to show the match view
            if not self.last_interaction:
                raise RuntimeError(f"Cannot display match view: no interaction stored for player {self.player.discord_user_id}")
            
            # Offload the embed generation to executor
            loop = asyncio.get_running_loop()
            embed = await loop.run_in_executor(None, match_view.get_embed)
            flow.checkpoint("generate_match_embed_complete")
            
            # Edit the existing searching message to show the match view
            flow.checkpoint("edit_to_match_view")
            await self.last_interaction.edit_original_response(
                embed=embed,
                view=match_view
            )
            
            # Store channel and message ID for future edits using bot token
            match_view.channel = self.last_interaction.channel
            
            # Get the message ID by fetching the original response
            original_message = await self.last_interaction.original_response()
            match_view.original_message_id = original_message.id
            
            # Register for replay detection
            await match_view.register_for_replay_detection(self.last_interaction.channel_id)
            
            flow.checkpoint("update_match_view_complete")
            print(f"[Match Notification] Successfully displayed match view for player {self.player.discord_user_id}")
            
            flow.checkpoint("cleanup_start")
            # Clean up
            await queue_searching_view_manager.unregister(self.player.discord_user_id, view=self)
            flow.checkpoint("cleanup_complete")
            
            flow.complete("match_displayed_successfully")
            
        finally:
            # Always unsubscribe when done, even if an error occurred
            await notification_service.unsubscribe(self.player.discord_user_id)

    async def on_timeout(self):
        """Handle view timeout"""
        # Clean up notification subscription
        await notification_service.unsubscribe(self.player.discord_user_id)
        
        # Cancel the match listener task
        if self.match_task:
            self.match_task.cancel()
        
        # Clean up this view from the manager
        await queue_searching_view_manager.unregister(self.player.discord_user_id, view=self)
        
        # Remove player from matchmaker if they are still in queue
        if await matchmaker.is_player_in_queue(self.player.discord_user_id):
            await matchmaker.remove_player(self.player.discord_user_id)
            print(f"🚪 Player {self.player.user_id} timed out and was removed from queue.")

    def deactivate(self) -> None:
        if not self.is_active:
            return
        self.is_active = False
        if self.status_task:
            self.status_task.cancel()
            self.status_task = None
        if self.match_task:
            self.match_task.cancel()
            self.match_task = None
    
    def set_interaction(self, interaction: discord.Interaction):
        """Store the interaction so we can update the message later"""
        self.last_interaction = interaction


class CancelQueueButton(discord.ui.Button):
    """Cancel button to exit the queue and return to original view"""
    
    def __init__(self, original_view, player):
        super().__init__(
            label="Cancel Queue",
            emoji="✖️",
            style=discord.ButtonStyle.danger,
            row=0
        )
        self.original_view = original_view
        self.player = player
    
    async def callback(self, interaction: discord.Interaction):
        parent_view = self.view

        # Proceed with cancelling the queue entry
        print(f"🚪 Removing player from matchmaker: {self.player.user_id}")
        await matchmaker.remove_player(self.player.discord_user_id)
        
        # Clean up the notification subscription and cancel the listener task
        await notification_service.unsubscribe(self.player.discord_user_id)
        
        # Stop the searching view's match listener task
        if isinstance(parent_view, QueueSearchingView) and parent_view.match_task:
            parent_view.match_task.cancel()
            parent_view.deactivate()
        
        await queue_searching_view_manager.unregister(self.player.discord_user_id, view=parent_view)
        
        # Return to the original queue view with its embed
        await interaction.response.edit_message(
            embed=self.original_view.get_embed(),
            view=self.original_view
        )


# Global dictionary to store match results by Discord user ID
match_results = {}

async def wait_for_match_completion(match_id: int, timeout: int = 30) -> Optional[dict]:
    """
    Wait for a match to be fully completed and return the final results.
    
    Args:
        match_id: The ID of the match to wait for
        timeout: Maximum time to wait in seconds (default: 30)
    
    Returns:
        Dictionary with final match results or None if timeout/error
    """
    try:
        # Wait for the match completion service to process the match
        final_results = await match_completion_service.wait_for_match_completion(match_id, timeout)
        
        if final_results:
            print(f"✅ Match {match_id} completed with results: {final_results}")
            return final_results
        else:
            print(f"⏰ Match {match_id} completion timed out after {timeout} seconds")
            return None
            
    except Exception as e:
        print(f"❌ Error waiting for match {match_id} completion: {e}")
        return None

def handle_match_result(match_result: MatchResult, register_completion_callback: Callable[[Callable], None]):
    """
    Handle when a match is found - publish via notification service.
    
    This callback is invoked by the matchmaker when a match is created.
    It uses the notification service to instantly push the result to both players.
    """
    print(f"🎉 Match #{match_result.match_id}: {match_result.player_1_user_id} vs {match_result.player_2_user_id} | {match_result.map_choice} @ {match_result.server_choice}")
    
    # Attach the register callback so views can subscribe to completion notifications
    setattr(match_result, 'register_completion_callback', register_completion_callback)
    
    # Publish match notification immediately via the notification service
    # This triggers instant push-based notifications to both players
    asyncio.create_task(notification_service.publish_match_found(match_result))


# Set the match callback
matchmaker.set_match_callback(handle_match_result)

class MatchFoundView(discord.ui.View):
    """View shown when a match is found"""
    
    def __init__(self, match_result: MatchResult, is_player1: bool):
        super().__init__(timeout=None)  # No timeout - let match completion service handle cleanup
        self.match_result = match_result
        self.is_player1 = is_player1
        self.selected_result = match_result.match_result
        self.confirmation_status = match_result.match_result_confirmation_status
        self.channel: Optional[discord.TextChannel] = None  # Store channel for long-running updates
        self.original_message_id: Optional[int] = None  # Store message ID for persistent editing
        self.edit_lock = asyncio.Lock()
        
        # Performance tracking
        self.view_creation_time = time.time()
        
        # Register this view's notification handler with the backend
        if hasattr(match_result, "register_completion_callback"):
            match_result.register_completion_callback(self.handle_completion_notification)

        # Add match result reporting dropdown (moved to row 0)
        self.result_select = MatchResultSelect(match_result, is_player1, self)
        self.add_item(self.result_select)
        
        # Add abort button (moved to row 0)
        self.abort_button = MatchAbortButton(self)
        self.add_item(self.abort_button)

        # Add confirmation dropdown
        self.confirm_select = MatchResultConfirmSelect(self)
        self.add_item(self.confirm_select)

        # Start a background task to disable the abort button when the timer expires
        self.abort_deadline = get_current_unix_timestamp() + matchmaker.ABORT_TIMER_SECONDS
        self.abort_disable_task = asyncio.create_task(self.disable_abort_after_delay())

        # Update dropdown states based on initial data
        self._update_dropdown_states()
    
    async def disable_abort_after_delay(self):
        """A background task to disable the abort button after the deadline."""
        await asyncio.sleep(matchmaker.ABORT_TIMER_SECONDS)

        # Double-check if the button should still be active
        if self.abort_button.disabled or self.match_result.match_result in ["aborted", "conflict", "player1_win", "player2_win", "draw"]:
            return

        self.abort_button.disabled = True

        # Try to update the message
        async with self.edit_lock:
            # Update the embed to notify the user
            embed = self.get_embed()  # Get the current embed state
            embed.add_field(name="⚠️ Abort Window Closed", value="The time to abort this match has expired.", inline=False)
            
            # Edit the original message using bot token (never expires!)
            await self._edit_original_message(embed, self)
    
    async def _edit_original_message(self, embed: discord.Embed, view: discord.ui.View = None) -> bool:
        """
        Edit the original match message using the stored message ID.
        This uses the bot's permanent token, not the temporary interaction token.
        
        Returns True if successful, False otherwise.
        """
        if not self.channel or not self.original_message_id:
            return False
        
        try:
            # Fetch the original message by ID using the bot's permanent token
            message = await self.channel.fetch_message(self.original_message_id)
            
            # Edit it using the bot's permanent token (never expires!)
            await message.edit(embed=embed, view=view or self)
            return True
        except (discord.NotFound, discord.Forbidden, discord.HTTPException) as e:
            print(f"Failed to edit original message: {e}")
            return False
    
    def _update_dropdown_states(self):
        """Update the state of the dropdowns based on the current view state"""
        # If a replay has been uploaded, enable result selection
        if self.match_result.replay_uploaded == "Yes":
            self.result_select.disabled = False
            self.result_select.placeholder = "Report match result..."
            if self.selected_result:
                # Result has been selected but not confirmed, enable confirmation dropdown
                self.confirm_select.disabled = False
                self.confirm_select.placeholder = "Confirm your selection..."
                
                # Update confirmation dropdown options
                if self.selected_result == "player1_win":
                    result_label = f"{self.result_select.p1_name} victory"
                elif self.selected_result == "player2_win":
                    result_label = f"{self.result_select.p2_name} victory"
                else:
                    result_label = "Draw"
                
                self.confirm_select.options = [
                    discord.SelectOption(
                        label=f"Confirm: {result_label}",
                        value="confirm"
                    )
                ]
                
            # Set default value for result dropdown
            for option in self.result_select.options:
                if option.value == self.selected_result:
                    option.default = True
                else:
                    option.default = False
            else:
                # No result selected yet, disable confirmation dropdown
                self.confirm_select.disabled = True
                self.confirm_select.placeholder = "Select result first..."
                
                # Clear any default selections
                for option in self.result_select.options:
                    option.default = False
        else:
            # No replay uploaded yet, disable both dropdowns
            self.result_select.disabled = True
            self.result_select.placeholder = "Upload replay file to enable result reporting"
            self.confirm_select.disabled = True
            self.confirm_select.placeholder = "Upload replay file first"
    
    def get_embed(self) -> discord.Embed:
        """Get the match found embed"""
        import time
        from src.backend.services.app_context import leaderboard_service
        start_time = time.perf_counter()
        
        # Get player 1 info from DataAccessService (sub-millisecond, in-memory)
        checkpoint1 = time.perf_counter()
        from src.backend.services.data_access_service import DataAccessService
        data_service = DataAccessService()
        p1_info = data_service.get_player_info(self.match_result.player_1_discord_id)
        
        p1_name = p1_info.get('player_name') if p1_info else None
        p1_country = p1_info.get('country') if p1_info else None
        p1_display_name = p1_name if p1_name else str(self.match_result.player_1_discord_id)
        p1_flag = get_flag_emote(p1_country) if p1_country else get_flag_emote("XX")
        
        # Get player 2 info from DataAccessService (sub-millisecond, in-memory)
        p2_info = data_service.get_player_info(self.match_result.player_2_discord_id)
        
        checkpoint2 = time.perf_counter()
        print(f"⏱️ [MatchEmbed PERF] Player info lookup: {(checkpoint2-checkpoint1)*1000:.2f}ms")
        
        p2_name = p2_info.get('player_name') if p2_info else None
        p2_country = p2_info.get('country') if p2_info else None
        p2_display_name = p2_name if p2_name else str(self.match_result.player_2_discord_id)
        p2_flag = get_flag_emote(p2_country) if p2_country else get_flag_emote("XX")
        
        # Get race information from match result
        p1_race = self.match_result.player_1_race
        p2_race = self.match_result.player_2_race
        
        # Get race emotes
        p1_race_emote = get_race_emote(p1_race)
        p2_race_emote = get_race_emote(p2_race)
        
        checkpoint3 = time.perf_counter()
        # Use cached ranks from MatchResult (no dynamic calculation needed)
        p1_rank = self.match_result.player_1_rank or "u_rank"
        p2_rank = self.match_result.player_2_rank or "u_rank"
        checkpoint4 = time.perf_counter()
        print(f"  [MatchEmbed PERF] Rank lookup: {(checkpoint4-checkpoint3)*1000:.2f}ms")
        
        # Get rank emotes
        p1_rank_emote = get_rank_emote(p1_rank)
        p2_rank_emote = get_rank_emote(p2_rank)
        
        checkpoint5 = time.perf_counter()
        # Get MMR values from DataAccessService (in-memory, sub-millisecond)
        p1_mmr, p2_mmr = data_service.get_match_mmrs(self.match_result.match_id)
        checkpoint6 = time.perf_counter()
        print(f"  [MatchEmbed PERF] Match data lookup: {(checkpoint6-checkpoint5)*1000:.2f}ms")
        
        # Create title with new format: rank, flag, race, name, MMR
        title = f"Match #{self.match_result.match_id}: {p1_rank_emote} {p1_flag} {p1_race_emote} {p1_display_name} ({p1_mmr}) vs {p2_rank_emote} {p2_flag} {p2_race_emote} {p2_display_name} ({p2_mmr})"
        
        # Get race names for display using races service
        p1_race_name = race_service.get_race_name(p1_race)
        p2_race_name = race_service.get_race_name(p2_race)
        
        # Get server information with region using regions service
        server_display = regions_service.format_server_with_region(self.match_result.server_choice)
        
        # Build player information with alt IDs and rank letters: rank, flag, race, name, race_name
        p1_info_line = f"- Player 1: {p1_rank_emote} {p1_flag} {p1_race_emote} {p1_display_name} ({p1_race_name})"
        if p1_info:
            alt_ids_1 = []
            if p1_info.get('alt_player_name_1'):
                alt_ids_1.append(p1_info.get('alt_player_name_1'))
            if p1_info.get('alt_player_name_2'):
                alt_ids_1.append(p1_info.get('alt_player_name_2'))
            if alt_ids_1:
                p1_info_line += f"\n  - a.k.a. {', '.join(alt_ids_1)}"
        
        p2_info_line = f"- Player 2: {p2_rank_emote} {p2_flag} {p2_race_emote} {p2_display_name} ({p2_race_name})"
        if p2_info:
            alt_ids_2 = []
            if p2_info.get('alt_player_name_1'):
                alt_ids_2.append(p2_info.get('alt_player_name_1'))
            if p2_info.get('alt_player_name_2'):
                alt_ids_2.append(p2_info.get('alt_player_name_2'))
            if alt_ids_2:
                p2_info_line += f"\n  - a.k.a. {', '.join(alt_ids_2)}"
        
        embed = discord.Embed(
            title=title,
            description="",  # Empty description as requested
            color=discord.Color.teal()
        )
        
        # Player Information section
        embed.add_field(
            name="**Player Information:**",
            value=f"{p1_info_line}\n{p2_info_line}",
            inline=False
        )
        
        # Match Information section
        map_short_name = self.match_result.map_choice
        map_name = maps_service.get_map_name(map_short_name) or map_short_name

        # Determine map link based on server region
        map_link: Optional[str] = None
        server_code = self.match_result.server_choice
        if server_code:
            region_info = regions_service.get_game_region_for_server(server_code)
            if region_info:
                region_name = region_info["name"].lower()
                if "americas" in region_name:
                    map_link = maps_service.get_map_battlenet_link(map_short_name, "americas")
                elif "europe" in region_name:
                    map_link = maps_service.get_map_battlenet_link(map_short_name, "europe")
                elif "asia" in region_name:
                    map_link = maps_service.get_map_battlenet_link(map_short_name, "asia")

        if not map_link:
            # Fallback to Americas link if specific region not available
            map_link = maps_service.get_map_battlenet_link(map_short_name, "americas")

        map_author = maps_service.get_map_author(map_short_name)
        map_link_display = map_link if map_link else "Unavailable"
        
        embed.add_field(
            name="**Match Information:**",
            value=(
                f"- Map: `{map_name}`\n"
                f"  - Map Link: `{map_link_display}`\n"
                f"  - Author: `{map_author}`\n"
                f"- Server: `{server_display}`\n"
                f"- In-Game Channel: `{self.match_result.in_game_channel}`"
            ),
            inline=False
        )
        
        # Match Result section
        
        if self.match_result.match_result == 'conflict':
            result_display = "Conflict"
            mmr_display = "- MMR Awarded: :x: Report Conflict Detected"
        elif self.match_result.match_result == 'aborted':
            # Get match data from DataAccessService (in-memory, instant)
            from src.backend.services.data_access_service import DataAccessService
            data_service = DataAccessService()
            match_data = data_service.get_match(self.match_result.match_id)
            if not match_data:
                raise ValueError(f"[MatchFoundView] Match {self.match_result.match_id} not found in DataAccessService memory")
            
            p1_report = match_data.get("player_1_report")
            p2_report = match_data.get("player_2_report")

            if p1_report == -3:
                aborted_by = p1_display_name
            elif p2_report == -3:
                aborted_by = p2_display_name
            else:
                aborted_by = "Unknown"

            result_display = f"Aborted by {aborted_by}"
            mmr_display = "- MMR Awarded: `+/-0` (Match aborted)"
        elif self.match_result.match_result:
            # Convert to human-readable format
            if self.match_result.match_result == "player1_win":
                result_display = f"{p1_display_name} victory"
            elif self.match_result.match_result == "player2_win":
                result_display = f"{p2_display_name} victory"
            else:  # draw or other value
                print(f"⚠️ EMBED: Unexpected match_result value: '{self.match_result.match_result}'")
                result_display = "Draw"
            
            # Always show MMR field - calculate MMR changes
            p1_mmr_change = getattr(self.match_result, 'p1_mmr_change', None)
            p2_mmr_change = getattr(self.match_result, 'p2_mmr_change', None)
            
            if p1_mmr_change is not None and p2_mmr_change is not None:
                # Round MMR changes to integers using MMR service
                p1_mmr_rounded = mmr_service.round_mmr_change(p1_mmr_change)
                p2_mmr_rounded = mmr_service.round_mmr_change(p2_mmr_change)
                
                # Format MMR changes with proper signs
                p1_sign = "+" if p1_mmr_rounded >= 0 else ""
                p2_sign = "+" if p2_mmr_rounded >= 0 else ""
                
                mmr_display = f"- MMR Awarded: `{p1_display_name}: {p1_sign}{p1_mmr_rounded}`, `{p2_display_name}: {p2_sign}{p2_mmr_rounded}`"
            else:
                # MMR changes not calculated yet - always show TBD
                mmr_display = f"- MMR Awarded: `{p1_display_name}: TBD`, `{p2_display_name}: TBD`"
        else:
            result_display = "Not selected"
            mmr_display = f"- MMR Awarded: `{p1_display_name}: TBD`, `{p2_display_name}: TBD`"
            
        embed.add_field(
            name="**Match Result:**",
            value= (
                f"- Result: `{result_display}`\n"
                f"{mmr_display}"
            ),
            inline=False
        )
        
        # Replay section
        replay_status_value = (
            f"- Replay Uploaded: `{self.match_result.replay_uploaded}`\n"
            f"- Replay Uploaded At: {format_discord_timestamp(self.match_result.replay_upload_time)}"
            if self.match_result.replay_uploaded == "Yes"
            else f"- Replay Uploaded: `{self.match_result.replay_uploaded}`"
        )
        embed.add_field(name="**Replay Status:**", value=replay_status_value, inline=False)

        # Abort validity section
        # Get abort timer deadline (current time + ABORT_TIMER_SECONDS)
        current_time = get_current_unix_timestamp()
        
        checkpoint7 = time.perf_counter()
        # Get remaining aborts for both players
        p1_aborts = user_info_service.get_remaining_aborts(self.match_result.player_1_discord_id)
        p2_aborts = user_info_service.get_remaining_aborts(self.match_result.player_2_discord_id)
        checkpoint8 = time.perf_counter()
        print(f"  [MatchEmbed PERF] Abort count lookup: {(checkpoint8-checkpoint7)*1000:.2f}ms")
        
        abort_validity_value = (
            f"You can use the button below to abort the match if you are unable to play.\n"
            f"Aborting matches has no MMR penalty, but you have a limited number per month.\n" 
            f"Abusing this feature (e.g., dodging opponents/matchups, repeatedly aborting at\n"
            f"the last second, deliberately wasting the time of others, etc.) will result in a ban.\n"
            f"You can only abort the match before <t:{self.abort_deadline}:T> (<t:{self.abort_deadline}:R>)."
        )
        embed.add_field(name="**Can't play? Need to leave?**", value=abort_validity_value, inline=False)
        
        total_time = (time.perf_counter() - start_time) * 1000
        if total_time > 100:
            print(f"⚠️ [ME] Total:{total_time:.1f}ms")
        elif total_time > 50:
            print(f"🟡 [ME] Total:{total_time:.1f}ms")
        
        return embed

    async def register_for_replay_detection(self, channel_id: int):
        """Register this view to receive replay file uploads"""
        self.channel_id = channel_id
        await match_found_view_manager.register(
            self.match_result.match_id, channel_id, self
        )
    
    async def handle_completion_notification(self, status: str, data: dict):
        """This is the callback that the backend will invoke."""
        flow = FlowTracker(f"match_completion_notification_{status}", 
                          user_id=self.match_result.player_1_discord_id if self.is_player1 else self.match_result.player_2_discord_id)
        
        flow.checkpoint("notification_received")
        
        if status == "complete":
            flow.checkpoint("process_complete_status")
            # Update the view's internal state with the final results
            result_raw = data.get('match_result_raw')
            result_map = {
                1: "player1_win",
                2: "player2_win",
                0: "draw",
                -1: "aborted",
                -2: "conflict"
            }
            mapped_result = result_map.get(result_raw)

            self.match_result.match_result = mapped_result
            self.match_result.p1_mmr_change = data.get('p1_mmr_change')
            self.match_result.p2_mmr_change = data.get('p2_mmr_change')
            if mapped_result:
                self.match_result.match_result_confirmation_status = "Confirmed"
            
            flow.checkpoint("disable_components")
            # Disable components and update the original embed
            self.disable_all_components()
            
            flow.checkpoint("update_embed_start")
            async with self.edit_lock:
                # Edit the original message using bot token (never expires!)
                embed = self.get_embed()
                await self._edit_original_message(embed, self)
            flow.checkpoint("update_embed_complete")
            
            flow.checkpoint("send_final_embed_start")
            # Send the final gold embed as a follow-up
            await self._send_final_notification_embed(data)
            flow.checkpoint("send_final_embed_complete")
            
            flow.complete("success")
            
        elif status == "abort":
            flow.checkpoint("process_abort_status")
            # Update the view's internal state to reflect the abort
            self.match_result.match_result = "aborted"
            self.match_result.match_result_confirmation_status = "Aborted"

            flow.checkpoint("disable_components")
            # Immediately disable all components to prevent further actions
            self.disable_all_components()

            flow.checkpoint("update_abort_embed_start")
            # Update the embed with the abort information
            async with self.edit_lock:
                if self.last_interaction:
                    try:
                        await self.last_interaction.edit_original_response(
                            embed=self.get_embed(),
                            view=self
                        )
                    except discord.HTTPException:
                        pass  # Non-critical if this fails, the main state is updated
            flow.checkpoint("update_abort_embed_complete")

            flow.checkpoint("send_abort_embed_start")
            # Send a follow-up notification to ensure the user sees the final state
            await self._send_abort_notification_embed()
            flow.checkpoint("send_abort_embed_complete")
            
            # The view's work is done
            self.stop()
            flow.complete("success")
            
        elif status == "conflict":
            flow.checkpoint("process_conflict_status")
            # Update the view's state to reflect the conflict
            self.match_result.match_result = "conflict"
            
            flow.checkpoint("disable_components")
            # Disable components and update the original embed
            self.disable_all_components()
            
            flow.checkpoint("update_conflict_embed_start")
            async with self.edit_lock:
                if self.last_interaction:
                    await self.last_interaction.edit_original_response(
                        embed=self.get_embed(),
                        view=self
                    )
            flow.checkpoint("update_conflict_embed_complete")

            flow.checkpoint("send_conflict_embed_start")
            # Send the conflict embed as a follow-up
            await self._send_conflict_notification_embed()
            flow.checkpoint("send_conflict_embed_complete")
            
            flow.complete("success")

        # The view's work is done
        self.stop()
        
    async def _send_final_notification_embed(self, final_results: dict):
        """Creates and sends the final gold embed notification."""
        if not self.last_interaction:
            return

        p1_info = final_results['p1_info']
        p2_info = final_results['p2_info']
        p1_name = final_results['p1_name']
        p2_name = final_results['p2_name']

        p1_flag = get_flag_emote(p1_info['country'])
        p2_flag = get_flag_emote(p2_info['country'])
        p1_race = final_results['p1_race']
        p2_race = final_results['p2_race']
        p1_race_emote = get_race_emote(p1_race)
        p2_race_emote = get_race_emote(p2_race)

        # Get rank emotes for both players
        from src.backend.services.app_context import ranking_service
        
        p1_rank = ranking_service.get_rank(final_results['player_1_discord_uid'], p1_race)
        p2_rank = ranking_service.get_rank(final_results['player_2_discord_uid'], p2_race)
        
        p1_rank_emote = get_rank_emote(p1_rank)
        p2_rank_emote = get_rank_emote(p2_rank)

        p1_current_mmr = final_results['p1_current_mmr']
        p2_current_mmr = final_results['p2_current_mmr']
        p1_mmr_change = final_results['p1_mmr_change']
        p2_mmr_change = final_results['p2_mmr_change']
        p1_new_mmr = p1_current_mmr + p1_mmr_change
        p2_new_mmr = p2_current_mmr + p2_mmr_change

        p1_mmr_rounded = mmr_service.round_mmr_change(p1_mmr_change)
        p2_mmr_rounded = mmr_service.round_mmr_change(p2_mmr_change)

        notification_embed = discord.Embed(
            title=f"🏆 Match #{self.match_result.match_id} Result Finalized",
            description=f"**{p1_rank_emote} {p1_flag} {p1_race_emote} {p1_name} ({int(p1_current_mmr)} → {int(p1_new_mmr)})** vs **{p2_rank_emote} {p2_flag} {p2_race_emote} {p2_name} ({int(p2_current_mmr)} → {int(p2_new_mmr)})**",
            color=discord.Color.gold()
        )

        p1_sign = "+" if p1_mmr_rounded >= 0 else ""
        p2_sign = "+" if p2_mmr_rounded >= 0 else ""

        notification_embed.add_field(
            name="**MMR Changes:**",
            value=f"- {p1_name}: `{p1_sign}{p1_mmr_rounded} ({int(p1_current_mmr)} → {int(p1_new_mmr)})`\n- {p2_name}: `{p2_sign}{p2_mmr_rounded} ({int(p2_current_mmr)} → {int(p2_new_mmr)})`",
            inline=False
        )
        
        try:
            await self.last_interaction.followup.send(embed=notification_embed, ephemeral=False)
        except discord.HTTPException as e:
            print(f"Error sending final notification for match {self.match_result.match_id}: {e}")

    async def _send_conflict_notification_embed(self):
        """Sends a new follow-up message indicating a match conflict."""
        if not self.last_interaction:
            return
            
        conflict_embed = discord.Embed(
            title="⚠️ Match Result Conflict",
            description="The reported results for this match do not agree. Please contact an administrator to resolve this dispute.",
            color=discord.Color.red()
        )
        try:
            await self.last_interaction.followup.send(embed=conflict_embed, ephemeral=False)
        except discord.HTTPException as e:
            print(f"Error sending conflict notification for match {self.match_result.match_id}: {e}")

    async def _send_abort_notification_embed(self):
        """Sends a follow-up message indicating the match was aborted."""
        if not self.last_interaction:
            return

        # Get match data from DataAccessService (in-memory, instant)
        from src.backend.services.data_access_service import DataAccessService
        data_service = DataAccessService()
        match_data = data_service.get_match(self.match_result.match_id)
        if not match_data:
            raise ValueError(f"[MatchFoundView] Match {self.match_result.match_id} not found in DataAccessService memory")

        p1_info = data_service.get_player_info(match_data['player_1_discord_uid'])
        p2_info = data_service.get_player_info(match_data['player_2_discord_uid'])

        p1_name = p1_info.get('player_name') if p1_info else str(match_data['player_1_discord_uid'])
        p2_name = p2_info.get('player_name') if p2_info else str(match_data['player_2_discord_uid'])

        aborted_by = "Unknown"
        if match_data.get("player_1_report") == -3:
            aborted_by = p1_name
        elif match_data.get("player_2_report") == -3:
            aborted_by = p2_name
            
        p1_flag = get_flag_emote(p1_info['country']) if p1_info else '🏳️'
        p2_flag = get_flag_emote(p2_info['country']) if p2_info else '🏳️'
        p1_race = match_data.get('player_1_race')
        p2_race = match_data.get('player_2_race')
        p1_race_emote = get_race_emote(p1_race)
        p2_race_emote = get_race_emote(p2_race)

        # Get rank emotes for both players
        from src.backend.services.app_context import ranking_service
        
        p1_rank = ranking_service.get_rank(match_data['player_1_discord_uid'], p1_race)
        p2_rank = ranking_service.get_rank(match_data['player_2_discord_uid'], p2_race)
        
        p1_rank_emote = get_rank_emote(p1_rank)
        p2_rank_emote = get_rank_emote(p2_rank)

        p1_current_mmr = match_data['player_1_mmr']
        p2_current_mmr = match_data['player_2_mmr']

        abort_embed = discord.Embed(
            title=f"🛑 Match #{self.match_result.match_id} Aborted",
            description=f"**{p1_rank_emote} {p1_flag} {p1_race_emote} {p1_name} ({int(p1_current_mmr)})** vs **{p2_rank_emote} {p2_flag} {p2_race_emote} {p2_name} ({int(p2_current_mmr)})**",
            color=discord.Color.red()
        )

        abort_embed.add_field(
            name="**MMR Changes:**",
            value=f"- {p1_name}: `+0 ({int(p1_current_mmr)})`\n- {p2_name}: `+0 ({int(p2_current_mmr)})`",
            inline=False
        )
        
        abort_embed.add_field(
            name="**Reason:**",
            value=f"The match was aborted by **{aborted_by}**. No MMR changes were applied.",
            inline=False
        )

        try:
            await self.last_interaction.followup.send(embed=abort_embed, ephemeral=False)
        except discord.HTTPException as e:
            print(f"Error sending abort notification for match {self.match_result.match_id}: {e}")

    def disable_all_components(self):
        """Disables all components in the view."""
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                item.disabled = True

    async def on_timeout(self):
        pass # Timeout is now handled by the match completion service


class MatchAbortButton(discord.ui.Button):
    """Button to abort the match"""
    
    def __init__(self, parent_view):
        self.parent_view = parent_view
        self.awaiting_confirmation = False  # Track confirmation state
        self.first_click_time = None  # Track timing
        viewer_id = (
            parent_view.match_result.player_1_discord_id
            if parent_view.is_player1
            else parent_view.match_result.player_2_discord_id
        )
        remaining_aborts = user_info_service.get_remaining_aborts(viewer_id)
        label_text = f"Abort Match ({remaining_aborts} left this month)"
        
        is_disabled = remaining_aborts == 0
        
        super().__init__(
            emoji="🛑",
            label=label_text,
            style=discord.ButtonStyle.secondary,
            row=0,
            disabled=is_disabled
        )
    
    async def callback(self, interaction: discord.Interaction):
        flow = FlowTracker(f"match_abort", user_id=interaction.user.id)
        player_discord_uid = interaction.user.id
        
        flow.checkpoint("check_confirmation_state")
        # If not yet in confirmation state, show confirmation prompt
        if not self.awaiting_confirmation:
            self.first_click_time = time.time()
            flow.checkpoint("show_confirmation_prompt")
            remaining_aborts = user_info_service.get_remaining_aborts(player_discord_uid)
            self.label = f"Confirm Abort ({remaining_aborts} remaining)"
            self.style = discord.ButtonStyle.danger  # Keep danger style
            self.awaiting_confirmation = True
            
            flow.checkpoint("update_button_ui_start")
            # Update the view to show the confirmation button
            async with self.parent_view.edit_lock:
                await interaction.response.edit_message(
                    embed=self.parent_view.get_embed(),
                    view=self.parent_view
                )
            flow.checkpoint("update_button_ui_complete")
            flow.complete("awaiting_confirmation")
            return
        
        # If already in confirmation state, proceed with abort
        if self.first_click_time:
            time_to_confirm = time.time() - self.first_click_time
            print(f"⏱️ [Abort PERF] Time between first click and confirmation: {time_to_confirm*1000:.2f}ms")
        
        flow.checkpoint("execute_abort_start")
        # Atomically abort the match
        success = await matchmaker.abort_match(
            self.parent_view.match_result.match_id,
            player_discord_uid
        )
        flow.checkpoint("execute_abort_complete")
        
        if success:
            flow.checkpoint("abort_succeeded")
            # The backend will now handle notifications.
            # We just need to update the UI to a disabled state.
            
            flow.checkpoint("update_ui_start")
            # Update button label
            remaining_aborts = user_info_service.get_remaining_aborts(player_discord_uid)
            self.label = f"Match Aborted ({remaining_aborts} left this month)"

            self.parent_view.disable_all_components()

            # Stop the abort disable task as the match is now aborted
            if self.parent_view.abort_disable_task and not self.parent_view.abort_disable_task.done():
                self.parent_view.abort_disable_task.cancel()
            
            flow.checkpoint("send_abort_ui_update")
            # Update the embed to show abort status temporarily
            # The backend will send the final authoritative state
            async with self.parent_view.edit_lock:
                await interaction.response.edit_message(
                    embed=self.parent_view.get_embed(), 
                    view=self.parent_view
                )
            flow.checkpoint("send_abort_ui_complete")
            flow.complete("success")
        else:
            flow.complete("abort_failed")
            await interaction.response.send_message("❌ Failed to abort match. It might have been already completed or aborted by the other player.")


class MatchResultConfirmSelect(discord.ui.Select):
    """Confirmation dropdown for match result"""
    
    def __init__(self, parent_view):
        self.parent_view = parent_view
        
        # Create placeholder option (will be replaced when result is selected)
        options = [
            discord.SelectOption(
                label="Awaiting selection...",
                value="placeholder"
            )
        ]
        
        super().__init__(
            placeholder="Select result first...",
            min_values=1,
            max_values=1,
            options=options,
            disabled=True,
            row=2
        )
    
    async def callback(self, interaction: discord.Interaction):
        flow = FlowTracker(f"confirm_match_result", user_id=interaction.user.id)
        
        flow.checkpoint("update_confirmation_status")
        # Persist the confirmation status
        self.parent_view.match_result.match_result_confirmation_status = "Confirmed"
        
        flow.checkpoint("update_ui_state")
        # Set the selected option as default for persistence
        for option in self.options:
            option.default = (option.value == self.values[0])
        
        # Disable both dropdowns and abort button after confirmation
        self.parent_view.result_select.disabled = True
        self.parent_view.confirm_select.disabled = True
        self.parent_view.abort_button.disabled = True
        self.parent_view.last_interaction = interaction

        # Stop the abort disable task as a result has been confirmed
        if self.parent_view.abort_disable_task and not self.parent_view.abort_disable_task.done():
            self.parent_view.abort_disable_task.cancel()

        flow.checkpoint("update_discord_message_start")
        # Update the message to show the final state before backend processing
        async with self.parent_view.edit_lock:
            await interaction.response.edit_message(
                embed=self.parent_view.get_embed(), view=self.parent_view
            )
        flow.checkpoint("update_discord_message_complete")

        flow.checkpoint("record_player_report_start")
        # Now, send the report to the backend for final processing.
        # The completion handler will send the final embed update.
        await self.parent_view.result_select.record_player_report(
            self.parent_view.selected_result
        )
        flow.checkpoint("record_player_report_complete")
        
        flow.complete("success")


class MatchResultSelect(discord.ui.Select):
    """Dropdown for reporting match results"""
    
    def __init__(self, match_result: MatchResult, is_player1: bool, parent_view):
        self.match_result = match_result
        self.is_player1 = is_player1
        self.parent_view = parent_view
        
        # Get player names from DataAccessService (in-memory, instant)
        from src.backend.services.data_access_service import DataAccessService
        data_service = DataAccessService()
        p1_info = data_service.get_player_info(match_result.player_1_discord_id)
        self.p1_name = p1_info.get('player_name') if p1_info else str(match_result.player_1_user_id)
        
        p2_info = data_service.get_player_info(match_result.player_2_discord_id)
        self.p2_name = p2_info.get('player_name') if p2_info else str(match_result.player_2_user_id)
        
        # Create options for the dropdown
        options = [
            discord.SelectOption(
                label=f"{self.p1_name} victory",
                value="player1_win"
            ),
            discord.SelectOption(
                label=f"{self.p2_name} victory", 
                value="player2_win"
            ),
            discord.SelectOption(
                label="Draw",
                value="draw"
            )
        ]
        
        super().__init__(
            placeholder="Report match result...",
            min_values=1,
            max_values=1,
            options=options,
            row=1
        )
    
    async def callback(self, interaction: discord.Interaction):
        flow = FlowTracker(f"select_match_result", user_id=interaction.user.id)
        
        flow.checkpoint("validate_replay_uploaded")
        # Check if replay is uploaded before allowing result selection
        if self.parent_view.match_result.replay_uploaded != "Yes":
            flow.complete("no_replay_uploaded")
            await interaction.response.send_message("❌ Please upload a replay file before reporting match results.")
            return
        
        flow.checkpoint("store_selected_result")
        # Store the selected result in parent view and persist it
        self.parent_view.selected_result = self.values[0]
        self.parent_view.match_result.match_result = self.values[0]
        
        # Set default value for result dropdown (for persistence)
        for option in self.options:
            option.default = (option.value == self.values[0])
        
        # Get result label for confirmation dropdown
        if self.values[0] == "player1_win":
            result_label = f"{self.p1_name} victory"
        elif self.values[0] == "player2_win":
            result_label = f"{self.p2_name} victory"
        else:
            result_label = "Draw"
        
        flow.checkpoint("update_confirmation_dropdown")
        # Enable and update confirmation dropdown
        self.parent_view.confirm_select.disabled = False
        self.parent_view.confirm_select.options = [
            discord.SelectOption(
                label=f"Confirm: {result_label}",
                value="confirm"
            )
        ]
        self.parent_view.confirm_select.placeholder = "Confirm your selection..."
        
        flow.checkpoint("update_message_start")
        # Update the message (DO NOT call _update_dropdown_states() as it would reset our changes)
        self.parent_view.last_interaction = interaction
        async with self.parent_view.edit_lock:
            await interaction.response.edit_message(
                embed=self.parent_view.get_embed(), view=self.parent_view
            )
        flow.checkpoint("update_message_complete")
        flow.complete("success")
    
    async def record_player_report(self, result: str):
        """Record a player's individual report for the match"""
        import time
        start_time = time.perf_counter()
        
        # Convert result to report value format
        if result == "player1_win":
            report_value = 1
        elif result == "player2_win":
            report_value = 2
        else:
            report_value = 0
        
        try:
            current_player_id = self.parent_view.match_result.player_1_discord_id if self.is_player1 else self.parent_view.match_result.player_2_discord_id
            
            checkpoint1 = time.perf_counter()
            success = await matchmaker.record_match_result(self.match_result.match_id, current_player_id, report_value)
            checkpoint2 = time.perf_counter()
            
            duration_ms = (checkpoint2 - checkpoint1) * 1000
            db_time = duration_ms
            
            if success:
                print(f"📝 Player report recorded for match {self.match_result.match_id}. Waiting for backend notification.")
            else:
                print(f"❌ Failed to record player report for match {self.match_result.match_id}")
        except Exception as e:
            print(f"❌ Error recording player report: {e}")
        finally:
            total_time = (time.perf_counter() - start_time) * 1000
            
            # Compact performance logging
            print(f"[Report] DB:{db_time:.1f}ms Total:{total_time:.1f}ms")
    
    async def update_embed_with_mmr_changes(self):
        """Update the embed to show MMR changes"""
        try:
            # Update the original message with new embed
            if hasattr(self.parent_view, 'last_interaction') and self.parent_view.last_interaction:
                embed = self.parent_view.get_embed()
                await self.parent_view.last_interaction.edit_original_response(
                    embed=embed,
                    view=self.parent_view
                )
            
        except Exception as e:
            print(f"❌ Error updating embed with MMR changes: {e}")
    
    # Removed handle_disagreement - no longer needed with individual reporting
    
    def get_selected_label(self):
        """Get the label for the selected result"""
        if self.values[0] == "player1_win":
            return f"{self.match_result.player_1_user_id} Won"
        elif self.values[0] == "player2_win":
            return f"{self.match_result.player_2_user_id} Won"
        else:
            return "Draw"
    
    async def notify_other_player_result(self, original_embed, result_embed):
        """Notify the other player about the match result"""
        # Notify both players about the result
        for player_id in [self.parent_view.match_result.player_1_discord_id, self.parent_view.match_result.player_2_discord_id]:
            other_view = await queue_searching_view_manager.get_view(player_id)
            if other_view and hasattr(other_view, 'last_interaction') and other_view.last_interaction:
                    try:
                        # Disable the dropdown in the other player's view
                        for item in other_view.children:
                            if isinstance(item, MatchResultSelect):
                                item.disabled = True
                                item.placeholder = f"Selected: {item.get_selected_label()}"
                        
                        # Update the other player's message
                        await other_view.last_interaction.edit_original_response(
                            embeds=[original_embed, result_embed],
                            view=other_view
                        )
                    except:
                        pass  # Interaction might be expired
    
    async def notify_other_player_disagreement(self, original_embed, disagreement_embed):
        """Notify the other player about the disagreement"""
        # Notify both players about the disagreement
        for player_id in [self.parent_view.match_result.player_1_discord_id, self.parent_view.match_result.player_2_discord_id]:
            other_view = await queue_searching_view_manager.get_view(player_id)
            if other_view and hasattr(other_view, 'last_interaction') and other_view.last_interaction:
                    try:
                        # Disable the dropdown in the other player's view
                        for item in other_view.children:
                            if isinstance(item, MatchResultSelect):
                                item.disabled = True
                                item.placeholder = f"Selected: {item.get_selected_label()}"
                        
                        # Update the other player's message
                        await other_view.last_interaction.edit_original_response(
                            embeds=[original_embed, disagreement_embed],
                            view=other_view
                        )
                    except:
                        pass  # Interaction might be expired
    
    async def record_player_report(self, result: str):
        """Record a player's individual report for the match"""
        # Convert result to report value format
        if result == "player1_win":
            report_value = 1
        elif result == "player2_win":
            report_value = 2
        else:
            report_value = 0
        
        try:
            current_player_id = self.parent_view.match_result.player_1_discord_id if self.is_player1 else self.parent_view.match_result.player_2_discord_id
            success = await matchmaker.record_match_result(self.match_result.match_id, current_player_id, report_value)
            
            if success:
                print(f"📝 Player report recorded for match {self.match_result.match_id}. Waiting for backend notification.")
            else:
                print(f"❌ Failed to record player report for match {self.match_result.match_id}")
        except Exception as e:
            print(f"❌ Error recording player report: {e}")
    
    async def update_embed_with_mmr_changes(self):
        """Update the embed to show MMR changes"""
        try:
            # Update the original message with new embed
            if hasattr(self.parent_view, 'last_interaction') and self.parent_view.last_interaction:
                embed = self.parent_view.get_embed()
                await self.parent_view.last_interaction.edit_original_response(
                    embed=embed,
                    view=self.parent_view
                )
            
        except Exception as e:
            print(f"❌ Error updating embed with MMR changes: {e}")
    
    # Removed handle_disagreement_silent - no longer needed with individual reporting


class BroodWarRaceSelect(discord.ui.Select):
    def __init__(self, default_value: Optional[str] = None):
        options = [
            discord.SelectOption(
                label=label,
                value=value,
                description=description,
                default=value == default_value,
            )
            for label, value, description in race_service.get_race_dropdown_groups()["brood_war"]
        ]
        super().__init__(
            placeholder="Select your Brood War race (max 1)",
            min_values=0,
            max_values=1,
            options=options,
            row=1,
        )

    async def callback(self, interaction: discord.Interaction):
        self.view.selected_bw_race = self.values[0] if self.values else None
        await self.view.persist_preferences()
        await self.view.update_embed(interaction)


class StarCraftRaceSelect(discord.ui.Select):
    def __init__(self, default_value: Optional[str] = None):
        options = [
            discord.SelectOption(
                label=label,
                value=value,
                description=description,
                default=value == default_value,
            )
            for label, value, description in race_service.get_race_dropdown_groups()["starcraft2"]
        ]
        super().__init__(
            placeholder="Select your StarCraft II race (max 1)",
            min_values=0,
            max_values=1,
            options=options,
            row=2,
        )

    async def callback(self, interaction: discord.Interaction):
        self.view.selected_sc2_race = self.values[0] if self.values else None
        await self.view.persist_preferences()
        await self.view.update_embed(interaction)


async def store_replay_background(match_id: int, player_id: int, replay_bytes: bytes, replay_info: dict, channel):
    """Background task to store replay without blocking UI updates"""
    try:
        print(f"[Background] Starting replay storage for match {match_id} (player: {player_id})")
        
        # Use the async method for non-blocking database writes
        result = await replay_service.store_upload_from_parsed_dict_async(
            match_id,
            player_id,
            replay_bytes,
            replay_info
        )
        
        if result.get("success"):
            # Send replay details embed as a new message
            replay_data = result.get("replay_data")
            if replay_data:
                replay_embed = ReplayDetailsEmbed.get_success_embed(replay_data)
                await channel.send(embed=replay_embed)
            
            print(f"✅ Background replay storage completed for match {match_id} (player: {player_id})")
        else:
            error_message = result.get("error")
            print(f"❌ Background replay storage failed for match {match_id}: {error_message}")
            
    except Exception as e:
        print(f"❌ Background replay storage error for match {match_id}: {e}")
        import traceback
        traceback.print_exc()


async def on_message(message: discord.Message, bot=None):
    """
    Listen for SC2Replay file uploads in channels with active match views.
    Uses multiprocessing to parse replays without blocking the event loop.
    
    Args:
        message: The Discord message containing the replay attachment
        bot: The bot instance (required to access the process pool)
    """
    # Ignore bot messages
    if message.author.bot:
        return
    
    # Check if there are any attachments
    if not message.attachments:
        return
    
    # Check if any attachment is an SC2Replay file
    replay_attachment = None
    
    for attachment in message.attachments:
        if replay_service.is_sc2_replay(attachment.filename):
            replay_attachment = attachment
            break  # Take the first SC2Replay file and ignore the rest
    
    if not replay_attachment:
        return
    
    # Find the corresponding match view from the channel map
    match_view = channel_to_match_view_map.get(message.channel.id)
    
    if not match_view:
        return
    
    flow = FlowTracker(f"replay_upload", user_id=message.author.id)
    
    try:
        flow.checkpoint("download_replay_start")
        # Download the replay file
        replay_bytes = await replay_attachment.read()
        flow.checkpoint("download_replay_complete")
        
        print(f"[Main Process] Replay uploaded by {message.author.name} "
              f"(size: {len(replay_bytes)} bytes). Offloading to worker process...")
        
        flow.checkpoint("parse_replay_start")
        # --- MULTIPROCESSING INTEGRATION ---
        # Get the current asyncio event loop
        loop = asyncio.get_running_loop()
        
        # Offload the blocking parsing function to the process pool
        # The 'await' here does NOT block the bot. It pauses this
        # function and lets the event loop run other tasks.
        try:
            if bot and hasattr(bot, 'process_pool'):
                # Event-driven process pool health check
                # Only check when we actually need to use the pool
                try:
                    from src.backend.services.process_pool_health import ensure_process_pool_healthy
                    is_healthy = await ensure_process_pool_healthy()
                    if not is_healthy:
                        print("[WARN] Process pool health check failed, falling back to synchronous parsing")
                        replay_info = parse_replay_data_blocking(replay_bytes)
                    else:
                        # Track work start
                        if hasattr(bot, '_track_work_start'):
                            bot._track_work_start()
                        
                        # Log memory before replay parsing
                        from src.backend.services.memory_monitor import log_memory
                        log_memory("Before replay parse")
                        
                        try:
                            replay_info = await loop.run_in_executor(
                                bot.process_pool, parse_replay_data_blocking, replay_bytes
                            )
                        finally:
                            # Track work end
                            if hasattr(bot, '_track_work_end'):
                                bot._track_work_end()
                            
                            # Log memory after replay parsing
                            log_memory("After replay parse")
                except Exception as e:
                    print(f"[WARN] Process pool health check failed with error: {e}")
                    # Continue with process pool usage - let the executor handle the error
                    # Track work start
                    if hasattr(bot, '_track_work_start'):
                        bot._track_work_start()
                    
                    try:
                        replay_info = await loop.run_in_executor(
                            bot.process_pool, parse_replay_data_blocking, replay_bytes
                        )
                    finally:
                        # Track work end
                        if hasattr(bot, '_track_work_end'):
                            bot._track_work_end()
            else:
                # Fallback to synchronous parsing if process pool is not available
                # This shouldn't happen in production, but provides a safety net
                print("[WARN] Process pool not available, falling back to synchronous parsing")
                replay_info = parse_replay_data_blocking(replay_bytes)
                
        except Exception as e:
            # This will catch any exception from the worker process
            print(f"[FATAL] Replay parsing in worker process failed: {type(e).__name__}: {e}")
            flow.complete("parse_failed")
            error_embed = ReplayDetailsEmbed.get_error_embed(
                "A critical error occurred while parsing the replay. "
                "The file may be corrupted. Please notify an admin."
            )
            await message.channel.send(embed=error_embed)
            return
        
        flow.checkpoint("parse_replay_complete")
        print(f"[Main Process] Received result from worker process")
        
        flow.checkpoint("validate_replay_data")
        # Check if parsing failed
        if replay_info.get("error"):
            error_message = replay_info["error"]
            print(f"[Main Process] Worker process reported parsing error: {error_message}")
            
            flow.complete("validation_failed")
            # Send the red error embed
            error_embed = ReplayDetailsEmbed.get_error_embed(error_message)
            await message.channel.send(embed=error_embed)
            
            # Update the match view to show "Replay Invalid"
            match_view.match_result.replay_uploaded = "Replay Invalid"
            match_view._update_dropdown_states()
            
            # Edit the original message using bot token (never expires!)
            embed = match_view.get_embed()
            await match_view._edit_original_message(embed, match_view)
            
            print(f"❌ Failed to parse replay for match {match_view.match_result.match_id}: {error_message}")
            return
        
        # IMMEDIATE UI UPDATE - Don't wait for storage to complete
        flow.checkpoint("immediate_ui_update_start")
        unix_epoch = int(time.time())
        match_view.match_result.replay_uploaded = "Yes"
        match_view.match_result.replay_upload_time = unix_epoch
        
        # Update ONLY the view for the player who uploaded the replay
        # Each player should only see their own replay status
        match_view._update_dropdown_states()
        
        # Edit the original message using bot token (never expires!)
        embed = match_view.get_embed()
        await match_view._edit_original_message(embed, match_view)
        flow.checkpoint("immediate_ui_update_complete")
        
        # Start background storage task (non-blocking)
        flow.checkpoint("start_background_storage")
        asyncio.create_task(store_replay_background(
            match_view.match_result.match_id,
            message.author.id,
            replay_bytes,
            replay_info,
            message.channel
        ))
        
        print(f"✅ Replay upload UI updated immediately for match {match_view.match_result.match_id} (player: {message.author.id})")
        flow.complete("success")

    except Exception as e:
        flow.complete("error")
        print(f"❌ Error processing replay file: {e}")

